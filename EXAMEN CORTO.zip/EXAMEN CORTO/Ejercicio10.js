function areaRectangulo(lado1, lado2) {
    return lado1 * lado2;
}


console.log(areaRectangulo(5, 10));  
