function cuadrado(numero) {
    return numero * numero;
}


console.log(cuadrado(5));  
