function DividirPor3(numero) {
    return numero % 3 === 0;
}

console.log(DividirPor3(9));  
console.log(DividirPor3(10)); 
console.log(DividirPor3(15)); 
