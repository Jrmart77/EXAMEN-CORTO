function añadirTexto(texto) {
    return "El usuario ha escrito: " + texto;
}


console.log(añadirTexto("HOLA MI NOMBRE ES MARLON MARTINEZ"));  
console.log(añadirTexto("GUASTATOYA BICAMBEON"));