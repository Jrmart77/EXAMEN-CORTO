function Rango(num1, num2) {
    if ((num1 >= 100 && num1 <= 200) && (num2 >= 100 && num2 <= 200)) {
        return "sí";
    } else {
        return "no";
    }
}


console.log(Rango(150, 180)); 
console.log(Rango(90, 150));  