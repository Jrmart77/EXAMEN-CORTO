function Descomponer(numero) {
    if (numero < 1000 || numero > 9999) {
        return "El número debe tener 4 dígitos.";
    }

    const unidadesDeMillar = Math.floor(numero / 1000) * 1000;
    const centenas = Math.floor((numero % 1000) / 100) * 100;
    const decenas = Math.floor((numero % 100) / 10) * 10;
    const unidades = numero % 10;

    return `Unidades de millar: ${unidadesDeMillar}, centenas: ${centenas}, decenas: ${decenas}, unidades: ${unidades}`;
}


console.log(Descomponer(1347)); 
console.log(Descomponer(4725)); 
