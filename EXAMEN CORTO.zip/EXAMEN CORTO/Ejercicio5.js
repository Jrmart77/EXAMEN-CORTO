function Rango(num1, num2) {
    if (((num1 >= 0 && num1 <= 50) || (num1 >= 100 && num1 <= 150)) &&
        ((num2 >= 0 && num2 <= 50) || (num2 >= 100 && num2 <= 150))) {
        return "sí";
    } else {
        return "no";
    }
}


console.log(Rango(30, 120)); 
console.log(Rango(60, 130)); 
