function sumarYMostrar(num1, num2) {
    const suma = num1 + num2;

    if (suma > 100) {
        console.log(suma);
    } else {
        alert(suma);  
    }
}


sumarYMostrar(60, 50);  
sumarYMostrar(30, 40);  



