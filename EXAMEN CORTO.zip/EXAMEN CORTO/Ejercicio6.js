function TresDigitos(numero) {
    if (numero >= 100 && numero <= 999) {
        return "sí";
    } else if (numero <= -100 && numero >= -999) {
        return "sí";
    } else {
        return "no";
    }
}

// Ejemplo de uso
console.log(TresDigitos(123));  // "sí"
console.log(TresDigitos(99));   // "no"

