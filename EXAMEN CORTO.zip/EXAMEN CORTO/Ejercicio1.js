function diferenciaConQuince(numero) {
    if (numero <= 15) {
        return "Error: El número es negativo o igual a 15";
    } else {
        return numero - 15;
    }
}

console.log(diferenciaConQuince(20));  
console.log(diferenciaConQuince(10)); 
console.log(diferenciaConQuince(15));  
console.log(diferenciaConQuince(-5));  