function TrianguloRectangulo(cateto1, cateto2) {
    return (cateto1 * cateto2) / 2;
}


console.log(TrianguloRectangulo(3, 4)); 
