function concatenar(array) {
    return array[347] + array[222];
}


const miArray = Array(348).fill('').map((_, i) => `elemento${i}`);

console.log(concatenar(miArray)); 
